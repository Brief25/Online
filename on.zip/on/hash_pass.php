<?php
require_once __DIR__ . "/server/connection.php";

if (!isset($pdo)) {
    die("❌ Database connection not available.");
}

/* ================= CREATE NEW USER ================= */
if (isset($_POST['create_user'])) {

    $userid = trim($_POST['userid']);
    $name = trim($_POST['name']);
    $password = trim($_POST['password']);

    if ($userid === "" || $name === "" || $password === "") {
        $create_error = "❌ All fields are required.";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        try {
            $stmt = $pdo->prepare(
                "INSERT INTO user (user_id, name, password) VALUES (?, ?, ?)"
            );
            $stmt->execute([$userid, $name, $hashed]);

            $create_success = "✅ User created successfully!";
        } catch (Exception $e) {
            $create_error = "❌ Error: " . $e->getMessage();
        }
    }
}

/* ================= AUTO-DETECT ID COLUMN ================= */
$columns = $pdo->query("DESCRIBE user")->fetchAll();
$idColumn = null;

foreach ($columns as $col) {
    if ($col['Field'] === 'user_id' || $col['Field'] === 'id') {
        $idColumn = $col['Field'];
        break;
    }
}

if (!$idColumn) {
    die("❌ Could not detect ID column in user table.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Manager</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f5f5f5;
            padding: 40px;
        }
        .box {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            max-width: 520px;
            margin: 20px auto;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
        }
        input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
        }
        button {
            width: 100%;
            padding: 12px;
            background: black;
            color: white;
            border: none;
            cursor: pointer;
        }
        .success { color: green; font-weight: bold; text-align: center; }
        .error { color: red; font-weight: bold; text-align: center; }
    </style>
</head>
<body>

<!-- ================= CREATE USER FORM ================= -->
<div class="box">
    <h2>Create New User</h2>

    <?php if (!empty($create_success)) echo "<p class='success'>$create_success</p>"; ?>
    <?php if (!empty($create_error)) echo "<p class='error'>$create_error</p>"; ?>

    <form method="POST">
        <input type="text" name="userid" placeholder="User ID" required>
        <input type="text" name="name" placeholder="Full Name" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="create_user">Create User</button>
    </form>
</div>

<!-- ================= PASSWORD HASHING TOOL ================= -->
<div class="box">
    <h2>Password Hashing Tool</h2>

    <?php
    try {
        $stmt = $pdo->query("SELECT $idColumn, password FROM user");
        $users = $stmt->fetchAll();

        foreach ($users as $row) {

            $plain = $row['password'];

            if (password_get_info($plain)['algo'] === 0) {

                $hash = password_hash($plain, PASSWORD_DEFAULT);
                $userid = $row[$idColumn];

                $update = $pdo->prepare(
                    "UPDATE user SET password = ? WHERE $idColumn = ?"
                );
                $update->execute([$hash, $userid]);

                echo "<p>✅ Hashed ID: <strong>$userid</strong></p>";
            }
        }

        echo "<p class='success'>✅ DONE! All plain-text passwords are now hashed.</p>";

    } catch (Exception $e) {
        echo "<p class='error'>❌ Error: " . $e->getMessage() . "</p>";
    }
    ?>
</div>

</body>
</html>
