<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

/* PHPMailer Files */
require_once __DIR__ . '/../config/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../config/PHPMailer-master/src/SMTP.php';
require_once __DIR__ . '/../config/PHPMailer-master/src/Exception.php';

/* ================================
   EMAIL CONFIGURATION (SECURE)
================================ */

// ✅ AFTER YOU REGENERATE A NEW APP PASSWORD, PUT IT HERE
define('MAIL_FROM_EMAIL', 'cybernet6533@gmail.com');
define('MAIL_FROM_NAME', 'Auth System');
define('MAIL_APP_PASSWORD', 'rtob crqj qnid lkub');

/* ================================
   BASE MAIL CONFIG FUNCTION
================================ */

function configureMailer(): PHPMailer {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = MAIL_FROM_EMAIL;
    $mail->Password   = MAIL_APP_PASSWORD;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    $mail->setFrom(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
    $mail->addReplyTo(MAIL_FROM_EMAIL, MAIL_FROM_NAME);

    $mail->isHTML(true);
    $mail->CharSet = 'UTF-8';
    $mail->Timeout = 30;

    return $mail;
}

/* ================================
   OTP EMAIL
================================ */

function sendOTPEmail($toEmail, $toName, $otp): bool {
    try {
        $mail = configureMailer();
        $mail->addAddress($toEmail, $toName);
        $mail->Subject = 'Email Verification OTP';

        $mail->Body = "
            <h2>Hello, $toName</h2>
            <p>Your OTP for email verification is:</p>
            <h3 style='letter-spacing:2px;'>$otp</h3>
            <p>This OTP is valid for <b>10 minutes</b>.</p>
            <p>If you did not request this OTP, ignore this email.</p>
            <br>
            <p>Regards,<br><b>Auth System</b></p>
        ";

        $mail->AltBody = "Your OTP is: $otp (Valid for 10 minutes)";
        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("OTP Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}

/* ================================
   WELCOME EMAIL
================================ */

function sendWelcomeEmail($toEmail, $toName): bool {
    try {
        $mail = configureMailer();
        $mail->addAddress($toEmail, $toName);

        $mail->Subject = '🎉 Welcome to Auth System! Your Registration is Complete';

        // HTML email body with professional theme
        $mail->Body = "
        <html>
        <head>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f6f8;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    background-color: #ffffff;
                    width: 100%;
                    max-width: 600px;
                    margin: 40px auto;
                    padding: 30px;
                    border-radius: 12px;
                    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .header {
                    color: #2E86DE;
                    font-size: 28px;
                    margin-bottom: 20px;
                }
                .content {
                    font-size: 16px;
                    color: #333333;
                    line-height: 1.6;
                    margin-bottom: 30px;
                }
                .btn {
                    display: inline-block;
                    padding: 12px 25px;
                    background-color: #2E86DE;
                    color: #ffffff;
                    text-decoration: none;
                    border-radius: 6px;
                    font-weight: bold;
                    transition: background 0.3s ease;
                }
                .btn:hover {
                    background-color: #1B4F72;
                }
                .footer {
                    font-size: 14px;
                    color: #777777;
                    margin-top: 30px;
                }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>Welcome, $toName!</div>
                <div class='content'>
                    Your account has been successfully created in <b>Auth System</b>.<br>
                    You can now log in using your credentials and start exploring the platform.
                </div>
                <a href='http://yourwebsite.com/login.php' class='btn'>Login Now</a>
                <div class='footer'>
                    If you did not register, please ignore this email.<br>
                    Regards,<br>
                    <b>Auth System Team</b>
                </div>
            </div>
        </body>
        </html>
        ";

        // Fallback for non-HTML email clients
        $mail->AltBody = "Hello $toName, Your account has been created successfully. Login here: http://yourwebsite.com/login.php";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("Welcome Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}


/* ================================
   LOGIN SECURITY ALERT
================================ */

function sendLoginAlertEmail($toEmail, $toName): bool {
    try {
        $mail = configureMailer();
        $mail->addAddress($toEmail, $toName);

        $mail->Subject = 'Security Alert: Failed Login Attempts';
        $mail->Body = "
            <h3>Hello, $toName</h3>
            <p>We detected multiple failed login attempts on your account.</p>
            <p>If this was not you, reset your password immediately.</p>
            <br>
            <p>Regards,<br><b>Auth System Security Team</b></p>
        ";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("Login Alert Error: " . $mail->ErrorInfo);
        return false;
    }
}

/* ================================
   GENERAL MAIL SERVICE CLASS
================================ */

class MailService {

    public function sendMail($to, $name, $subject, $body): bool {
        try {
            $mail = configureMailer();
            $mail->addAddress($to, $name);
            $mail->Subject = $subject;
            $mail->Body    = $body;
            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("General Mail Error: " . $mail->ErrorInfo);
            return false;
        }
    }
}


/* ================================
   SEND USER ID & PASSWORD EMAIL
================================ */

function sendCredentialsEmail($toEmail, $toName, $userId, $plainPassword): bool {
    try {
        $mail = configureMailer();
        $mail->addAddress($toEmail, $toName);

        $mail->Subject = '🎯 Your Login Credentials for Auth System';

        $mail->Body = "
        <html>
        <head>
            <style>
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background-color: #f4f6f8;
                    margin: 0;
                    padding: 0;
                }
                .container {
                    background-color: #ffffff;
                    width: 100%;
                    max-width: 600px;
                    margin: 40px auto;
                    padding: 30px;
                    border-radius: 12px;
                    box-shadow: 0 8px 20px rgba(0,0,0,0.1);
                    text-align: center;
                }
                .header {
                    color: #2E86DE;
                    font-size: 26px;
                    margin-bottom: 20px;
                }
                .content {
                    font-size: 16px;
                    color: #333333;
                    line-height: 1.6;
                    margin-bottom: 25px;
                }
                .credentials {
                    background: #f1f3f6;
                    padding: 15px 20px;
                    border-radius: 8px;
                    margin-bottom: 25px;
                    font-weight: bold;
                    color: #2c3e50;
                }
                .note {
                    color: #e74c3c;
                    font-weight: bold;
                    margin-bottom: 25px;
                }
                .btn {
                    display: inline-block;
                    padding: 12px 25px;
                    background-color: #2E86DE;
                    color: #ffffff;
                    text-decoration: none;
                    border-radius: 6px;
                    font-weight: bold;
                    transition: background 0.3s ease;
                }
                .btn:hover {
                    background-color: #1B4F72;
                }
                .footer {
                    font-size: 14px;
                    color: #777777;
                    margin-top: 25px;
                }
            </style>
        </head>
        <body>
            <div class='container'>
                <div class='header'>Hello, $toName!</div>
                <div class='content'>
                    Your account has been created successfully in <b>Auth System</b>.
                </div>
                <div class='credentials'>
                    User ID: $userId <br>
                    Password: $plainPassword
                </div>
                <div class='note'>
                    Please change your password after your first login.
                </div>
                <a href='http://yourwebsite.com/login.php' class='btn'>Login Now</a>
                <div class='footer'>
                    If you did not register, please ignore this email.<br>
                    Regards,<br><b>Auth System Team</b>
                </div>
            </div>
        </body>
        </html>
        ";

        // Fallback for non-HTML email clients
        $mail->AltBody = "Hello $toName, Your account is created.\nUser ID: $userId\nPassword: $plainPassword\nPlease change your password after first login.\nLogin here: http://yourwebsite.com/login.php";

        $mail->send();
        return true;

    } catch (Exception $e) {
        error_log("Credentials Mail Error: " . $mail->ErrorInfo);
        return false;
    }
}
