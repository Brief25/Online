<?php
session_start();

// DB connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project3";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$message = "";
if (isset($_POST['register'])) {

    $user_id = trim($_POST['user_id']);
    $name    = trim($_POST['name']);
    $role    = trim($_POST['role']);
    $plain_password = trim($_POST['password']);

    if (empty($user_id) || empty($name) || empty($plain_password) || empty($role)) {
        $message = "❌ All fields are required.";
    } else {

        // Hash the password
        $hashed_password = password_hash($plain_password, PASSWORD_BCRYPT);

        // Prepare and execute insert query
        $stmt = $conn->prepare(
            "INSERT INTO `user` (user_id, name, password, role) VALUES (?, ?, ?, ?)"
        );

        $stmt->bind_param("ssss", $user_id, $name, $hashed_password, $role);

        if ($stmt->execute()) {
            $message = "✅ $role registered successfully! You can now login.";
        } else {
            $message = "❌ Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin / Head Registration</title>
<style>
    /* Global */
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #fff7f0;
        margin: 0;
        padding: 0;
    }

    /* Center container */
    .container {
        max-width: 450px;
        margin: 60px auto;
        background: #ffffff;
        padding: 40px 30px;
        border-radius: 12px;
        box-shadow: 0 12px 25px rgba(255, 140, 0, 0.2);
        border-top: 6px solid #ff6f00;
    }

    h2 {
        text-align: center;
        color: #ff6f00;
        margin-bottom: 25px;
    }

    label {
        font-weight: bold;
        display: block;
        margin-top: 15px;
        color: #333;
    }

    input, select {
        width: 100%;
        padding: 12px;
        margin-top: 5px;
        border-radius: 6px;
        border: 1px solid #ffcc99;
        box-sizing: border-box;
        font-size: 14px;
    }

    button {
        width: 100%;
        padding: 12px;
        margin-top: 25px;
        background: #ff6f00;
        color: #fff;
        font-size: 16px;
        font-weight: bold;
        border: none;
        border-radius: 8px;
        cursor: pointer;
        transition: background 0.3s ease;
    }

    button:hover {
        background: #e65c00;
    }

    .message {
        margin-bottom: 20px;
        padding: 12px;
        border-radius: 6px;
        text-align: center;
        font-weight: bold;
    }

    .message.success {
        background: #fff3e0;
        color: #ff6f00;
    }

    .message.error {
        background: #ffe6e6;
        color: #ff0000;
    }
</style>
</head>
<body>

<div class="container">
    <h2>Register Admin / Head</h2>

    <?php if($message): ?>
        <div class="message <?php echo strpos($message,'✅')===0?'success':'error'; ?>">
            <?php echo $message; ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="user_id">User ID:</label>
        <input type="text" id="user_id" name="user_id" placeholder="Enter User ID" required>

        <label for="name">Name:</label>
        <input type="text" id="name" name="name" placeholder="Enter Full Name" required>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" placeholder="Enter Password" required>

        <label for="role">Role:</label>
        <select id="role" name="role" required>
            <option value="">Select Role</option>
            <option value="admin">Admin</option>
            <option value="head">Head</option>
        </select>

        <button type="submit" name="register">Register</button>
    </form>
</div>

</body>
</html>
