<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: auth.php");
    exit;
}

$con = mysqli_connect("localhost", "root", "", "project3") or die("Connection failed: " . mysqli_connect_error());

// Fetch quizzes for the dropdown
$quiz_query = "SELECT id, title FROM quiz";
$quiz_result = mysqli_query($con, $quiz_query);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_questions'])) {
    $quiz_id = $_POST['quiz_id'];
    $num_questions = $_POST['num_questions'];

    // Store the number of questions in a session for next form submission
    $_SESSION['quiz_id'] = $quiz_id;
    $_SESSION['num_questions'] = $num_questions;

    header("Location: add_questions_details.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Create Questions | Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
/* Global Reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}

/* Body & Background */
body {
    background-color: #fdf6f0;
    color: #333;
    min-height: 100vh;
}

/* Header */
header {
    background-color: #ff6600;
    color: #fff;
    padding: 20px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
header h1 {
    font-size: 26px;
    font-weight: 600;
}
header a {
    color: white;
    text-decoration: none;
    font-weight: 500;
    background: rgba(255,255,255,0.2);
    padding: 8px 15px;
    border-radius: 6px;
    transition: 0.3s;
}
header a:hover {
    background: white;
    color: #ff6600;
}

/* Container */
.container {
    max-width: 500px;
    margin: 50px auto;
    background: #fff;
    padding: 35px 40px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}
.container:hover {
    transform: translateY(-3px);
}

/* Form Elements */
form label {
    display: block;
    margin-top: 15px;
    font-weight: 600;
    color: #ff6600;
}
form select, form input {
    width: 100%;
    padding: 12px 15px;
    margin-top: 6px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
    transition: 0.3s;
}
form select:focus, form input:focus {
    outline: none;
    border-color: #ff6600;
    box-shadow: 0 0 8px rgba(255,102,0,0.3);
}

/* Submit Button */
form button {
    margin-top: 25px;
    width: 100%;
    padding: 15px;
    background-color: #ff6600;
    color: white;
    border: none;
    font-size: 18px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s;
}
form button:hover {
    background-color: #e55b00;
    box-shadow: 0 5px 15px rgba(255,102,0,0.3);
}

/* Responsive */
@media (max-width: 600px) {
    .container {
        padding: 25px;
        margin: 20px;
    }
}
</style>
</head>
<body>

<header>
    <h1>Create Questions</h1>
    <a href="admindashboard.php">Back to Dashboard</a>
</header>

<div class="container">
    <form method="POST">
        <label for="quiz_id">Select Exam:</label>
        <select name="quiz_id" id="quiz_id" required>
            <option value="">-- Select Exam --</option>
            <?php while ($quiz = mysqli_fetch_assoc($quiz_result)) { ?>
                <option value="<?php echo $quiz['id']; ?>"><?php echo htmlspecialchars($quiz['title']); ?></option>
            <?php } ?>
        </select>

        <label for="num_questions">Number of Questions:</label>
        <input type="number" name="num_questions" id="num_questions" min="1" placeholder="Enter number of questions" required>

        <button type="submit" name="create_questions">Next</button>
    </form>
</div>

</body>
</html>
