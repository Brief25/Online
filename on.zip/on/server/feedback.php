<?php
require("connection.php"); // This must create $pdo

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Sanitize inputs
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $subject = trim($_POST['subject']);
    $message = trim($_POST['message']);

    if (!empty($name) && !empty($email) && !empty($subject) && !empty($message)) {

        try {
            $stmt = $pdo->prepare(
                "INSERT INTO contacts (name, email, subject, message) 
                 VALUES (:name, :email, :subject, :message)"
            );

            $stmt->execute([
                ':name'    => $name,
                ':email'   => $email,
                ':subject' => $subject,
                ':message' => $message
            ]);

            echo "<script>
                    alert('Your message has been sent successfully!');
                    window.location.href = '../index.php';
                  </script>";

        } catch (PDOException $e) {
            echo "Database Error: " . $e->getMessage();
        }

    } else {
        echo "<script>alert('All fields are required!'); history.back();</script>";
    }
}
?>

