<?php
session_start();
$conn = new mysqli("localhost", "root", "", "project3");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "SELECT * FROM feedback ORDER BY id DESC"; // fallback if created_at is missing
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Feedback</title>
<style>
    body { font-family: 'Poppins', sans-serif; background: #fdf6f0; color: #333; margin:0; padding:0; }
    header { background: #ff6600; color: #fff; padding: 20px; text-align: center; font-size: 24px; font-weight: 600; }
    .container { max-width: 1200px; margin: 30px auto; padding: 0 20px; }
    table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
    th, td { padding: 12px; text-align: left; font-size: 14px; }
    th { background: #ff6600; color: #fff; }
    tr:nth-child(even) { background: #f9f9f9; }
    tr:hover { background: #fff3e0; }
    .search-container { display: flex; justify-content: flex-end; margin-bottom: 15px; }
    .search-container input { padding: 10px; border-radius: 8px; border: 1px solid #ccc; width: 300px; }
    .search-container input:focus { outline: none; border-color: #ff6600; box-shadow: 0 0 5px rgba(255,102,0,0.5); }
    @media (max-width: 900px) { table, .search-container { width: 100%; } th, td { font-size: 13px; padding: 10px; } .search-container input { width: 100%; } }
</style>
</head>
<body>

<header>Student Feedback Dashboard</header>

<div class="container">
    <div class="search-container">
        <input type="text" id="search" placeholder="Search feedback...">
    </div>
    <table id="feedback-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Subject</th>
                <th>Message</th>
                <th>Date Submitted</th>
            </tr>
        </thead>
        <tbody>
            <?php if($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['email']); ?></td>
                        <td><?php echo htmlspecialchars($row['subject']); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
                        <td><?php echo isset($row['created_at']) ? $row['created_at'] : '-'; ?></td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" style="text-align:center;">No feedback found.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script>
const searchInput = document.getElementById('search');
searchInput.addEventListener('input', () => {
    const filter = searchInput.value.toLowerCase();
    document.querySelectorAll('#feedback-table tbody tr').forEach(row => {
        row.style.display = Array.from(row.cells).map(cell => cell.textContent.toLowerCase()).join(' ').includes(filter) ? '' : 'none';
    });
});
</script>

</body>
</html>
<?php $conn->close(); ?>
