<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Results</title>
<style>
    /* Reset & general */
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', Arial, sans-serif; }
    body { background-color: #f4f6fa; color: #333; min-height: 100vh; }

    /* Header */
    header {
        background-color: #ff6600;
        color: white;
        padding: 20px 30px;
        text-align: center;
        font-size: 24px;
        font-weight: 600;
        box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    }

    /* Container */
    .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; }

    /* Table styles */
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    th, td {
        padding: 12px 15px;
        text-align: left;
        font-size: 14px;
    }
    th {
        background-color: #ff6600;
        color: white;
    }
    tr:nth-child(even) { background-color: #f9f9f9; }
    tr:hover { background-color: #fff3e0; }

    /* Responsive */
    @media (max-width: 768px) {
        th, td { font-size: 13px; padding: 10px; }
    }

    /* Section Title */
    h2 { color: #ff6600; margin-bottom: 20px; text-align: center; }
</style>
</head>
<body>

<header>Student Results</header>

<div class="container">
    <h2>Your Exam Results</h2>
    <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Exam ID</th>
                <th>Score</th>
                <th>Date & Time</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "project3";
            $user_id = $_SESSION["user_id"]; // from session

            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

            $stmt = $conn->prepare("SELECT * FROM results WHERE user_id = ?");
            $stmt->bind_param("s", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>".htmlspecialchars($row['user_id'])."</td>
                            <td>".htmlspecialchars($row['quiz_id'])."</td>
                            <td>".htmlspecialchars($row['score'])."</td>
                            <td>".htmlspecialchars($row['attempt_time'])."</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='4' style='text-align:center;'>No results found</td></tr>";
            }

            $stmt->close();
            $conn->close();
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
