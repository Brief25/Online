<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project3";

require_once __DIR__ . '/../mailer/MailService.php';

session_start();

// DB Connection
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

/* ================= USER ID & PASSWORD GENERATORS ================= */

function generateUserId($collegeName) {
    $formattedName = strtoupper(preg_replace('/[^a-zA-Z0-9]/', '', substr($collegeName, 0, 2)));
    $randomNumber = random_int(1000, 9999);
    return $formattedName . $randomNumber;
}

function generateNumericPassword($length = 8) {
    if ($length <= 0) return "";
    $numericCharacters = '0123456789';
    $password = '';
    $maxIndex = strlen($numericCharacters) - 1;

    for ($i = 0; $i < $length; $i++) {
        $password .= $numericCharacters[random_int(0, $maxIndex)];
    }
    return $password;
}

/* ================= USER REGISTRATION ================= */

if (isset($_POST['register'])) {

    $name = trim($_POST["name"]);
    $user_id = generateUserId($name);
    $password_plain = generateNumericPassword(8);
    $hashed_password = password_hash($password_plain, PASSWORD_BCRYPT);

    $email    = trim($_POST["email"]);
    $phone_no = trim($_POST["phone-no"]);
    $course   = trim($_POST["course"]);
    $year     = trim($_POST["year"]);
    $gender   = trim($_POST["gender"]);
    $dob      = trim($_POST["dob"]);

    $created_at = date("Y-m-d H:i:s");
    $updated_at = date("Y-m-d H:i:s");

    try {
        $stmt = $conn->prepare("
            INSERT INTO student 
            (user_id, password, name, email, phone_no, course, course_year, gender, dob, created_at, update_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->bind_param(
            "sssssssssss",
            $user_id,
            $hashed_password,
            $name,
            $email,
            $phone_no,
            $course,
            $year,
            $gender,
            $dob,
            $created_at,
            $updated_at
        );

      if ($stmt->execute()) {

    sendWelcomeEmail($email, $name);
    sendCredentialsEmail($email, $name, $user_id, $password_plain);

    // Output a professional success page
    echo "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Registration Successful</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f6fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .notification-card {
            background: #ffffff;
            padding: 40px 50px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.1);
            text-align: center;
            max-width: 400px;
            width: 100%;
            animation: fadeIn 1s ease;
        }
        .notification-card h1 {
            color: #2ecc71;
            margin-bottom: 15px;
        }
        .notification-card p {
            color: #333;
            margin-bottom: 25px;
        }
        .notification-card .redirect {
            color: #555;
            font-size: 14px;
            margin-bottom: 20px;
        }
        .btn-home {
            display: inline-block;
            padding: 12px 25px;
            background-color: #2E86DE;
            color: #ffffff;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: background 0.3s ease;
        }
        .btn-home:hover {
            background-color: #1B4F72;
        }
        @keyframes fadeIn {
            0% { opacity: 0; transform: translateY(-20px);}
            100% { opacity: 1; transform: translateY(0);}
        }
    </style>
</head>
<body>
    <div class='notification-card'>
        <h1>✅ Registration Successful!</h1>
        <p>Hi $name, your account has been created.<br>Check your email for login details.</p>
        <p class='redirect'>Redirecting to home page in <span id='countdown'>10</span> seconds...</p>
        <a href='../index.php' class='btn-home'>Go to Home Now</a>
    </div>

    <script>
        let seconds = 10;
        const countdown = document.getElementById('countdown');

        const timer = setInterval(() => {
            seconds--;
            countdown.textContent = seconds;
            if (seconds <= 0) {
                clearInterval(timer);
                window.location.href = '../index.php';
            }
        }, 1000);
    </script>
</body>
</html>
";


} else {
    throw new Exception($stmt->error);
}

        $stmt->close();

    } catch (Exception $e) {
        error_log($e->getMessage());
        echo "❌ Registration failed.";
    }
}

/* ================= UNIFIED LOGIN HANDLER ================= */
if (isset($_POST['userid'], $_POST['password'], $_POST['role'])) {

    $userid = trim($_POST['userid']);
    $password = trim($_POST['password']);
    $role = trim($_POST['role']);

    if ($role === 'student') {
        $stmt = $conn->prepare("SELECT user_id, name, password FROM student WHERE user_id = ?");
        $stmt->bind_param("s", $userid);
    } elseif ($role === 'admin' || $role === 'head') {
        $stmt = $conn->prepare("SELECT user_id, name, password FROM user WHERE user_id = ?");
        $stmt->bind_param("s", $userid);
    } else {
        die("❌ Invalid role.");
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    if ($row) {
        if (password_verify($password, $row['password'])) {

            $_SESSION['user_id'] = $row['user_id'];
            $_SESSION['username'] = $row['name'];

            if ($role === 'student') {
                header("Location: studentdashboard.php");
            } elseif ($role === 'admin') {
                header("Location: admindashboard.php");
            } elseif ($role === 'head') {
                header("Location: head_dashboard.php");
            }
            exit();

        } else {
            echo "<p style='color:red;'>❌ Wrong password.</p>";
        }
    } else {
        echo "<p style='color:red;'>❌ User not found.</p>";
    }

    $stmt->close();
}

$conn->close();
?>
