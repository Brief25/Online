<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project3";

// Create database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = htmlspecialchars(trim($_POST['title']));
    $intro = htmlspecialchars(trim($_POST['intro']));
    $start_date = htmlspecialchars(trim($_POST['start_date']));
    $last_date = htmlspecialchars(trim($_POST['last_date']));
    $time_limit = intval($_POST['time_limit']);

    try {
        $stmt = $conn->prepare("INSERT INTO quiz (title, intro, start_date, last_date, time_limit) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssi", $title, $intro, $start_date, $last_date, $time_limit);

        if ($stmt->execute()) {
            $successMessage = "Quiz added successfully!";
        } else {
            throw new Exception("Error executing query: " . $stmt->error);
        }
        $stmt->close();
    } catch (Exception $e) {
        error_log($e->getMessage());
        $errorMessage = "Something went wrong. Please try again.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Quiz | Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
/* Global Reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}

/* Body & Background */
body {
    background-color: #fdf6f0;
    color: #333;
    min-height: 100vh;
}

/* Header */
header {
    background-color: #ff6600;
    color: #fff;
    padding: 20px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
header h1 {
    font-size: 26px;
    font-weight: 600;
}
header a {
    color: white;
    text-decoration: none;
    font-weight: 500;
    background: rgba(255,255,255,0.2);
    padding: 8px 15px;
    border-radius: 6px;
    transition: 0.3s;
}
header a:hover {
    background: white;
    color: #ff6600;
}

/* Container */
.container {
    max-width: 700px;
    margin: 40px auto;
    background: #fff;
    padding: 35px 40px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}
.container:hover {
    transform: translateY(-3px);
}

/* Messages */
.message {
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 6px;
    font-weight: 500;
}
.success { background-color: #e8f6e8; color: #2e7d32; border-left: 5px solid #4caf50; }
.error { background-color: #ffe8e8; color: #c62828; border-left: 5px solid #ff4d4d; }

/* Form */
form label {
    display: block;
    margin-top: 15px;
    font-weight: 600;
    color: #ff6600;
}
form input, form textarea {
    width: 100%;
    padding: 12px 15px;
    margin-top: 6px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
    transition: 0.3s;
}
form input:focus, form textarea:focus {
    outline: none;
    border-color: #ff6600;
    box-shadow: 0 0 8px rgba(255,102,0,0.3);
}

/* Submit Button */
form button {
    margin-top: 25px;
    width: 100%;
    padding: 15px;
    background-color: #ff6600;
    color: white;
    border: none;
    font-size: 18px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s;
}
form button:hover {
    background-color: #e55b00;
    box-shadow: 0 5px 15px rgba(255,102,0,0.3);
}

/* Back Button */
.back-btn {
    display: inline-block;
    margin-bottom: 20px;
    padding: 10px 18px;
    background-color: #ff6600;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-weight: 500;
    transition: 0.3s;
}
.back-btn:hover {
    background-color: #e55b00;
    box-shadow: 0 4px 12px rgba(255,102,0,0.3);
}

/* Responsive */
@media (max-width: 600px) {
    .container {
        padding: 25px;
        margin: 20px;
    }
}
</style>
</head>
<body>

<header>
    <h1>Admin Panel</h1>
    <a href="admindashboard.php">Back to Dashboard</a>
</header>

<div class="container">

    <!-- Display success or error message -->
    <?php if(isset($successMessage)) : ?>
        <div class="message success"><?php echo $successMessage; ?></div>
    <?php elseif(isset($errorMessage)) : ?>
        <div class="message error"><?php echo $errorMessage; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="title">Exam Title / Subject:</label>
        <input type="text" id="title" name="title" placeholder="Enter exam title" required>
        
        <label for="intro">Introduction / Instructions:</label>
        <textarea id="intro" name="intro" rows="5" placeholder="Enter exam instructions or introduction"></textarea>
        
        <label for="start_date">Starting Date:</label>
        <input type="date" id="start_date" name="start_date" required>

        <label for="last_date">Last Date:</label>
        <input type="date" id="last_date" name="last_date" required>

        <label for="time_limit">Time Limit (in minutes):</label>
        <input type="number" id="time_limit" name="time_limit" placeholder="e.g., 60" required>
        
        <button type="submit">Add Quiz</button>
    </form>
</div>

</body>
</html>
