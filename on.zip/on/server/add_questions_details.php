<?php
session_start();
if (!isset($_SESSION['user_id']) || !isset($_SESSION['quiz_id']) || !isset($_SESSION['num_questions'])) {
    header("Location: add_questions.php");
    exit;
}

$con = mysqli_connect("localhost", "root", "", "project3") or die("Connection failed: " . mysqli_connect_error());

$quiz_id = $_SESSION['quiz_id'];
$num_questions = $_SESSION['num_questions'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_questions'])) {
    for ($i = 1; $i <= $num_questions; $i++) {
        $question = mysqli_real_escape_string($con, $_POST["question_$i"]);
        $option1 = mysqli_real_escape_string($con, $_POST["option1_$i"]);
        $option2 = mysqli_real_escape_string($con, $_POST["option2_$i"]);
        $option3 = mysqli_real_escape_string($con, $_POST["option3_$i"]);
        $option4 = mysqli_real_escape_string($con, $_POST["option4_$i"]);
        $correct_option = intval($_POST["correct_option_$i"]);

        $query = "INSERT INTO questions (quiz_id, question, option1, option2, option3, option4, correct_option) 
                  VALUES ('$quiz_id', '$question', '$option1', '$option2', '$option3', '$option4', '$correct_option')";
        mysqli_query($con, $query) or die("Error: " . mysqli_error($con));
    }

    unset($_SESSION['quiz_id'], $_SESSION['num_questions']); // Clear session variables
    echo "<h1 style='text-align:center; color:#2e7d32;'>Questions Added Successfully!</h1>";
    echo "<p style='text-align:center; margin-top:20px;'><a href='add_questions.php' style='color:#ff6600; text-decoration:none; margin-right:15px;'>Add More Questions</a> | <a href='index.php' style='color:#ff6600; text-decoration:none;'>Go to Home</a></p>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Add Questions Details | Admin Panel</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
<style>
/* Global Reset */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
}

/* Body & Background */
body {
    background-color: #fdf6f0;
    color: #333;
    min-height: 100vh;
    padding-bottom: 50px;
}

/* Header */
header {
    background-color: #ff6600;
    color: #fff;
    padding: 20px 30px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}
header h1 {
    font-size: 26px;
    font-weight: 600;
}
header a {
    color: white;
    text-decoration: none;
    font-weight: 500;
    background: rgba(255,255,255,0.2);
    padding: 8px 15px;
    border-radius: 6px;
    transition: 0.3s;
}
header a:hover {
    background: white;
    color: #ff6600;
}

/* Container */
.container {
    max-width: 700px;
    margin: 40px auto;
    background: #fff;
    padding: 35px 40px;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}
.container:hover {
    transform: translateY(-3px);
}

/* Fieldset Styling */
fieldset {
    border: 2px solid #ff6600;
    border-radius: 10px;
    padding: 20px;
    margin-bottom: 25px;
    transition: 0.3s;
}
fieldset:hover {
    box-shadow: 0 5px 15px rgba(255,102,0,0.2);
}
legend {
    font-weight: 600;
    color: #ff6600;
    padding: 0 10px;
}

/* Form Elements */
textarea, input[type="text"], input[type="number"] {
    width: 100%;
    padding: 12px 15px;
    margin-top: 10px;
    border: 1px solid #ddd;
    border-radius: 8px;
    font-size: 16px;
    transition: 0.3s;
}
textarea:focus, input:focus {
    outline: none;
    border-color: #ff6600;
    box-shadow: 0 0 8px rgba(255,102,0,0.3);
}

/* Submit Button */
button {
    margin-top: 25px;
    width: 100%;
    padding: 15px;
    background-color: #ff6600;
    color: white;
    border: none;
    font-size: 18px;
    font-weight: 600;
    border-radius: 8px;
    cursor: pointer;
    transition: 0.3s;
}
button:hover {
    background-color: #e55b00;
    box-shadow: 0 5px 15px rgba(255,102,0,0.3);
}

/* Responsive */
@media (max-width: 600px) {
    .container {
        padding: 25px;
        margin: 20px;
    }
}
</style>
</head>
<body>

<header>
    <h1>Add Questions</h1>
    <a href="add_questions.php">Back to Quiz Selection</a>
</header>

<div class="container">
    <form method="POST">
        <?php for ($i = 1; $i <= $num_questions; $i++) { ?>
            <fieldset>
                <legend>Question <?php echo $i; ?></legend>
                <textarea name="question_<?php echo $i; ?>" placeholder="Enter question here" required></textarea>
                <input type="text" name="option1_<?php echo $i; ?>" placeholder="Option 1" required>
                <input type="text" name="option2_<?php echo $i; ?>" placeholder="Option 2" required>
                <input type="text" name="option3_<?php echo $i; ?>" placeholder="Option 3" required>
                <input type="text" name="option4_<?php echo $i; ?>" placeholder="Option 4" required>
                <label for="correct_option_<?php echo $i; ?>">Correct Option (1-4):</label>
                <input type="number" name="correct_option_<?php echo $i; ?>" min="1" max="4" required>
            </fieldset>
        <?php } ?>
        <button type="submit" name="submit_questions">Submit Questions</button>
    </form>
</div>

</body>
</html>
