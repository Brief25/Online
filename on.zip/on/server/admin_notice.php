<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Create Notice</title>

<style>
    /* Reset & General */
    * {box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', Arial, sans-serif;}
    body {background-color: #f4f6fa; color: #333; min-height: 100vh;}

    /* Header */
    header {
        background-color: #ff6600;
        color: white;
        padding: 20px 30px;
        text-align: center;
        font-size: 24px;
        font-weight: 600;
        box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    }

    /* Container */
    .container {
        max-width: 900px;
        margin: 30px auto;
        padding: 0 20px;
    }

    /* Form */
    form {
        background-color: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        margin-bottom: 40px;
    }
    form h2 {
        margin-bottom: 20px;
        color: #ff6600;
        text-align: center;
    }
    form input, form textarea {
        width: 100%;
        padding: 12px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 14px;
        outline: none;
    }
    form input:focus, form textarea:focus {border-color: #ff6600;}
    form button {
        width: 100%;
        padding: 12px;
        background-color: #ff6600;
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 16px;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    form button:hover {background-color: #e65c00;}

    /* Notices Grid */
    .grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
    }
    .notice-card {
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .notice-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }
    .notice-card h3 {
        color: #ff6600;
        margin-bottom: 10px;
        font-size: 18px;
    }
    .notice-card p {
        color: #555;
        font-size: 14px;
        line-height: 1.5;
    }
    .notice-card .date {
        margin-top: 10px;
        font-size: 12px;
        color: #999;
        text-align: right;
    }

    /* Responsive */
    @media (max-width: 600px) {
        form, .grid {width: 100%;}
    }
</style>
</head>
<body>

<header>
    Admin - Create Notice
</header>

<div class="container">

    <!-- Create Notice Form -->
    <form method="POST" action="">
        <h2>Create New Notice</h2>
        <input type="text" name="title" placeholder="Notice Title" required>
        <textarea name="content" rows="5" placeholder="Write your notice here..." required></textarea>
        <button type="submit" name="submit">Post Notice</button>
    </form>

    <?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "project3";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

    // Save notice to database
    if (isset($_POST['submit'])) {
        $title = $_POST['title'];
        $content = $_POST['content'];

        $stmt = $conn->prepare("INSERT INTO notices (title, content, created_at) VALUES (?, ?, NOW())");
        $stmt->bind_param("ss", $title, $content);
        if ($stmt->execute()) {
            echo "<p style='text-align:center; color:green; margin-bottom:20px;'>Notice posted successfully!</p>";
        } else {
            echo "<p style='text-align:center; color:red; margin-bottom:20px;'>Error posting notice. Please try again.</p>";
        }
        $stmt->close();
    }

    // Fetch notices
    $sql = "SELECT * FROM notices ORDER BY created_at DESC";
    $result = $conn->query($sql);

    echo "<h2 style='color:#ff6600; margin-bottom:20px;'>Notices</h2>";
    echo "<div class='grid'>";
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<div class='notice-card'>
                    <h3>" . htmlspecialchars($row['title']) . "</h3>
                    <p>" . nl2br(htmlspecialchars($row['content'])) . "</p>
                    <p class='date'>Posted on: " . $row['created_at'] . "</p>
                  </div>";
        }
    } else {
        echo "<p style='text-align:center; color:#555;'>No notices found.</p>";
    }
    echo "</div>";

    $conn->close();
    ?>

</div>

</body>
</html>
