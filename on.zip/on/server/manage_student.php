<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Student Management</title>
<style>
    /* Reset & General */
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', Arial, sans-serif; }
    body { background-color: #f4f6fa; color: #333; min-height: 100vh; }

    /* Header */
    header {
        background-color: #ff6600;
        color: white;
        padding: 20px 30px;
        text-align: center;
        font-size: 24px;
        font-weight: 600;
        box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    }

    /* Container */
    .container {
        max-width: 1200px;
        margin: 30px auto;
        padding: 0 20px;
    }

    /* Search Form */
    form {
        display: flex;
        justify-content: center;
        margin-bottom: 20px;
        gap: 10px;
    }
    form input {
        padding: 10px 15px;
        border-radius: 8px;
        border: 1px solid #ccc;
        font-size: 14px;
        width: 250px;
    }
    form button {
        padding: 10px 20px;
        background-color: #ff6600;
        border: none;
        border-radius: 8px;
        color: white;
        font-weight: bold;
        cursor: pointer;
        transition: 0.3s;
    }
    form button:hover { background-color: #e65c00; }

    /* Table */
    table {
        width: 100%;
        border-collapse: collapse;
        background-color: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    th, td {
        padding: 12px 15px;
        text-align: left;
        font-size: 14px;
    }
    th {
        background-color: #ff6600;
        color: white;
    }
    tr:nth-child(even) { background-color: #f9f9f9; }
    tr:hover { background-color: #fff3e0; }

    /* Delete Button */
    .delete-btn {
        color: white;
        background-color: #ff4d4d;
        padding: 5px 10px;
        border-radius: 5px;
        text-decoration: none;
        font-size: 13px;
        transition: 0.3s;
    }
    .delete-btn:hover { background-color: #e60000; }

    /* Responsive */
    @media (max-width: 900px) {
        table, form { width: 100%; font-size: 12px; }
        th, td { padding: 10px; }
        form input { width: 150px; }
    }
</style>
</head>
<body>

<header>
    Admin Dashboard - Student Management
</header>

<div class="container">

    <!-- Search Student -->
    <form method="GET" action="">
        <input type="text" name="search" placeholder="Search by Name or ID">
        <button type="submit">Search</button>
    </form>

    <table>
        <thead>
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>E-mail</th>
                <th>Phone</th>
                <th>Course</th>
                <th>Year</th>
                <th>Gender</th>
                <th>DOB</th>
                <th>Created At</th>
                <th>Updated At</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Database Connection
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "project3";
            $conn = new mysqli($servername, $username, $password, $dbname);
            if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

            // Delete Student
            if (isset($_GET['delete'])) {
                $id = intval($_GET['delete']);
                $stmt = $conn->prepare("DELETE FROM student WHERE user_id = ?");
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $stmt->close();
            }

            // Search Students
            $search_query = "";
            if (isset($_GET['search']) && !empty($_GET['search'])) {
                $search = $conn->real_escape_string($_GET['search']);
                $search_query = "WHERE name LIKE '%$search%' OR user_id LIKE '%$search%'";
            }

            // Fetch Students
            $sql = "SELECT * FROM student $search_query ORDER BY user_id DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>{$row['user_id']}</td>
                        <td>{$row['name']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['phone_no']}</td>
                        <td>{$row['course']}</td>
                        <td>{$row['course_year']}</td>
                        <td>{$row['gender']}</td>
                        <td>{$row['dob']}</td>
                        <td>{$row['created_at']}</td>
                        <td>{$row['update_at']}</td>
                        <td><a href='?delete={$row['user_id']}' class='delete-btn' onclick=\"return confirm('Are you sure you want to delete this student?')\">Delete</a></td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='11' style='text-align:center;'>No records found</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>

</div>

</body>
</html>
