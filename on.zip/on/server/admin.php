<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "project3";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch total students
$totalStudents = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM student");
if ($result) {
    $row = $result->fetch_assoc();
    $totalStudents = $row['total'];
}

// Fetch total notices
$totalNotice = 0;
$result = $conn->query("SELECT COUNT(*) AS total FROM notices");
if ($result) {
    $row = $result->fetch_assoc();
    $totalNotice = $row['total'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | Online Examination System</title>
<style>
    /* Reset and General Styles */
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
        font-family: 'Poppins', Arial, sans-serif;
    }

    body {
        background-color: #f4f6fa;
        color: #333;
        min-height: 100vh;
    }

    /* Header */
    header {
        background-color: #ff6600;
        color: white;
        padding: 20px 30px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    }

    header h1 {
        font-size: 24px;
        font-weight: 600;
    }

    /* Navbar */
    nav {
        background-color: #222;
        display: flex;
        flex-wrap: wrap;
        padding: 15px 30px;
        gap: 15px;
    }

    nav a {
        color: white;
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 5px;
        transition: 0.3s;
    }

    nav a:hover {
        background-color: #ff6600;
        color: white;
    }

    nav .user-info {
        margin-left: auto;
        font-weight: bold;
    }

    nav .logout {
        color: #ff4d4d;
        margin-left: 15px;
    }

    /* Dashboard Layout */
    .container {
        display: flex;
        flex-wrap: wrap;
        padding: 30px;
        gap: 30px;
    }

    /* Sidebar */
    .sidebar {
        flex: 0 0 250px;
        background-color: #fff;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        height: fit-content;
    }

    .sidebar h3 {
        color: #ff6600;
        margin-bottom: 20px;
    }

    .sidebar a {
        display: block;
        color: #333;
        padding: 10px 12px;
        margin-bottom: 10px;
        border-radius: 6px;
        text-decoration: none;
        transition: 0.3s;
    }

    .sidebar a:hover {
        background-color: #ff6600;
        color: white;
    }

    /* Main Content */
    .main-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        gap: 30px;
    }

    .main-content h2 {
        margin-bottom: 20px;
        color: #ff6600;
    }

    /* Dashboard Cards */
    .grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
    }

    .card {
        background-color: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        transition: transform 0.3s, box-shadow 0.3s;
        text-align: center;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 20px rgba(0,0,0,0.15);
    }

    .card h3 {
        color: #333;
        font-size: 20px;
        margin-bottom: 10px;
    }

    .card p {
        font-size: 24px;
        color: #ff6600;
        font-weight: bold;
    }

    /* Responsive Design */
    @media (max-width: 900px) {
        .container {
            flex-direction: column;
        }

        .sidebar {
            width: 100%;
        }
    }

</style>
</head>
<body>

<header>
    <h1>Admin Dashboard</h1>
    <div class="user-info">
        User ID: <?php echo isset($_SESSION["user_id"]) ? $_SESSION["user_id"] : "Guest"; ?>
        <a href="logout.php" class="logout">Logout</a>
    </div>
</header>

<nav>
    <a href="#">Home</a>
    <a href="add-quiz.php">Add Exam</a>
    <a href="add_questions.php">Add Questions</a>
    <a href="manage_student.php">Manage Student</a>
    <a href="admin_notice.php">Notice</a>
</nav>

<div class="container">

    <!-- Sidebar -->
    <div class="sidebar">
        <h3>Quick Links</h3>
        <a href="add-quiz.php">Add Exam</a>
        <a href="add_questions.php">Add Questions</a>
        <a href="manage_student.php">Manage Students</a>
        <a href="admin_notice.php">Notice Board</a>
        <a href="logout.php" style="color: #ff4d4d;">Logout</a>
    </div>

    <!-- Main Content -->
    <section class="main-content">
        <h2>Welcome to the Dashboard</h2>

        <div class="grid">
            <div class="card">
                <h3>Total Students</h3>
                <p><?php echo $totalStudents; ?></p>
            </div>
            <div class="card">
                <h3>Blocked Students</h3>
                <p>0</p>
            </div>
            <div class="card">
                <h3>Total Notification Issued</h3>
                <p><?php echo $totalNotice; ?></p>
            </div>
            <div class="card">
                <h3>Active Sessions</h3>
                <p>89</p>
            </div>
        </div>
    </section>
</div>

</body>
</html>
