<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Student Dashboard</title>
<style>
    /* Reset & General */
    * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Poppins', Arial, sans-serif; }
    body { background-color: #f4f6fa; color: #333; min-height: 100vh; }

    /* Header */
    header {
        background-color: #ff6600;
        color: white;
        padding: 20px 30px;
        text-align: center;
        font-size: 24px;
        font-weight: 600;
        box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    }

    /* Navigation */
    nav {
        background-color: #222;
        color: white;
        padding: 15px 30px;
        display: flex;
        flex-wrap: wrap;
        gap: 15px;
        align-items: center;
    }
    nav a {
        color: white;
        text-decoration: none;
        padding: 8px 15px;
        border-radius: 5px;
        transition: 0.3s;
    }
    nav a:hover { background-color: #ff6600; color: white; }
    nav .user-info { margin-left: auto; font-weight: bold; }
    nav .logout { color: #ff4d4d; margin-left: 15px; }

    /* Main Container */
    .container { max-width: 1100px; margin: 30px auto; padding: 0 20px; }

    /* Section Titles */
    h2 { color: #ff6600; margin-bottom: 20px; }

    /* Notices */
    .notice-board {
        background-color: #fff3e0;
        border-left: 6px solid #ff6600;
        padding: 15px 20px;
        margin-bottom: 30px;
        border-radius: 8px;
        box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    }
    .notice-board h3 { margin-bottom: 10px; font-size: 18px; }
    .notice-board p { font-size: 14px; color: #555; }
    .notice-board .date { font-size: 12px; color: #888; margin-top: 5px; }

    /* Quiz Grid */
    .grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }
    .card {
        background-color: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        display: flex;
        flex-direction: column;
        justify-content: space-between;
        transition: transform 0.3s, box-shadow 0.3s;
    }
    .card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.15); }
    .card h2 { font-size: 20px; color: #333; margin-bottom: 10px; }
    .card p { font-size: 14px; color: #555; margin-bottom: 15px; }
    .join-link { text-align: right; }
    .join-link a {
        background-color: #ff6600;
        color: white;
        padding: 8px 15px;
        border-radius: 5px;
        text-decoration: none;
        font-weight: bold;
        transition: 0.3s;
    }
    .join-link a:hover { background-color: #e65c00; }

    /* Responsive */
    @media (max-width: 768px) {
        nav { justify-content: center; }
        nav .user-info { margin-left: 0; margin-top: 10px; width: 100%; text-align: center; }
        .grid { grid-template-columns: 1fr; }
    }
</style>
</head>
<body>

<header>Student Dashboard</header>

<nav>
    <a href="#">Home</a>
    <a href="result.php">Result</a>
    <div class="user-info">
        <?php echo "User ID: " . $_SESSION["user_id"]; ?>
        <a href="logout.php" class="logout">Logout</a>
    </div>
</nav>

<div class="container">

    <!-- Notice Board -->
    <section class="notice-section">
        <h2>Latest Notices</h2>
        <?php
        $con = mysqli_connect("localhost", "root", "", "project3") or die("Connection failed: " . mysqli_connect_error());
        $noticeQuery = "SELECT * FROM notices ORDER BY created_at DESC LIMIT 5"; // show 5 latest notices
        $noticeResult = mysqli_query($con, $noticeQuery);

        if(mysqli_num_rows($noticeResult) > 0){
            while($notice = mysqli_fetch_assoc($noticeResult)){ ?>
                <div class="notice-board">
                    <h3><?php echo htmlspecialchars($notice['title']); ?></h3>
                    <p><?php echo nl2br(htmlspecialchars($notice['content'])); ?></p>
                    <div class="date">Posted on: <?php echo $notice['created_at']; ?></div>
                </div>
        <?php }
        } else {
            echo "<p>No notices available.</p>";
        }
        ?>
    </section>

    <!-- Exams Section -->
    <section class="main-content">
        <h2>Available Exams</h2>
        <div class="grid">
            <?php
            $quizQuery = "SELECT * FROM quiz";
            $quizResult = mysqli_query($con, $quizQuery);

            if(mysqli_num_rows($quizResult) > 0){
                while ($quiz = mysqli_fetch_assoc($quizResult)) { ?>
                    <div class="card">
                        <h2><?php echo htmlspecialchars($quiz['title']); ?></h2>
                        <p><?php echo htmlspecialchars($quiz['intro']); ?></p>
                        <div class="join-link">
                            <a href="quiz.php?id=<?php echo $quiz['id']; ?>">Take Quiz</a>
                        </div>
                    </div>
            <?php }
            } else {
                echo "<p>No quizzes available at the moment.</p>";
            }
            mysqli_close($con);
            ?>
        </div>
    </section>
</div>

</body>
</html>
