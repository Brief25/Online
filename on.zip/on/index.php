<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Examination System</title>
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }

        body {
            background-color: #ffffff;
            color: #333;
        }

        /* Header */
        header {
            background-color: #ff6600; /* Orange */
            color: white;
            padding: 20px 50px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        header h1 {
            font-size: 28px;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 25px;
            font-weight: bold;
        }

        nav a:hover {
            text-decoration: underline;
        }

        /* Main Content */
        main {
            padding: 40px 50px;
        }

        /* Notifications Section */
        .notifications {
            margin-bottom: 50px;
        }

        .notifications h2 {
            color: #ff6600;
            margin-bottom: 15px;
            border-bottom: 2px solid #ff6600;
            display: inline-block;
            padding-bottom: 5px;
        }

        .notification-item {
            background-color: #f9f9f9;
            border-left: 5px solid #ff6600;
            padding: 15px;
            margin-bottom: 10px;
            transition: transform 0.2s;
        }

        .notification-item:hover {
            transform: scale(1.02);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        /* Exams Table Section */
        .exams {
            margin-bottom: 50px;
        }

        .exams h2 {
            color: #ff6600;
            margin-bottom: 15px;
            border-bottom: 2px solid #ff6600;
            display: inline-block;
            padding-bottom: 5px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: center;
        }

        table th {
            background-color: #333;
            color: white;
        }

        table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        table tr:hover {
            background-color: #ffe6cc;
        }

        .btn-join {
            background-color: #ff6600;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .btn-join:hover {
            background-color: #e65c00;
        }

        /* Footer */
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px;
        }

        @media (max-width: 768px) {
            header {
                flex-direction: column;
                text-align: center;
            }

            nav {
                margin-top: 10px;
            }

            table th, table td {
                font-size: 14px;
                padding: 10px;
            }
        }


        /* Logo Section Styles */
.logo-section {
    background-color: #ffffff; /* white background */
    text-align: center;
    padding: 20px 0;
    border-bottom: 2px solid #ff6600; /* subtle orange border */
}

.logo-section .logo {
    max-width: 500px;
    height: auto;
    display: inline-block;
    transition: transform 0.3s;
}

.logo-section .logo:hover {
    transform: scale(1.1); /* slight zoom on hover */
}
    </style>
</head>
<body>

    <!-- Header -->
    <header>
        <h1>Online Examination System</h1>
        <nav>
            <a href="#">Home</a>
            <a href="#exams">Exams</a>
            <a href="#notification">Notifications</a>
            <a href="#contact">Contact</a>
            <a href="public/views/login.html">Login</a>
        </nav>
    </header>

    <!-- Main Content -->
    <main>
        
        <!-- Logo Section (Add this above <header>) -->
<section class="logo-section">
    <img src="https://ik.imagekit.io/th8xabiur/0f42c7f6-1513-49e2-aad4-fc90b559a137.jpeg" loading="lazy" alt="Online Exam Logo" class="logo">
</section>

<!-- Notifications Section -->
<section class="notifications">
    <br>
    <h2 id="notification">Notifications</h2>

    <?php
    require("server/connection.php");

    $sql = "SELECT * FROM notices ORDER BY created_at DESC";
    $stmt = $pdo->query($sql);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!empty($rows)) {
        foreach ($rows as $row) {

            // Safe fallbacks in case fields are empty
            $title = !empty($row['title']) ? htmlspecialchars($row['title']) : 'No Title';
            $content = !empty($row['content']) ? nl2br(htmlspecialchars($row['content'])) : 'No Content';
            $date = !empty($row['created_at']) ? htmlspecialchars($row['created_at']) : '';

            echo '<div class="notification-item">
                    <strong>' . $title . '</strong><br>
                    ' . $content . '<br>
                    <small>' . $date . '</small>
                  </div>';
        }
    } else {
        echo '<div class="notification-item">No notifications available.</div>';
    }
    ?>
</section>

<section class="exams">
    <h2 id="exams">Upcoming Exams</h2>
    <table>
        <thead>
            <tr>
                <th>Subject</th>
                <th>Date</th>
                <th>Last Date</th>
                <th>Instruction</th>
                <th>Exam Duration</th>
            </tr>
        </thead>

        <tbody>
        <?php
        require("server/connection.php");

        $sql = "SELECT * FROM quiz ORDER BY start_date ASC";
        $stmt = $pdo->query($sql);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (!empty($rows)) {
            foreach ($rows as $row) {
                $title = htmlspecialchars($row['title']);
                $intro = htmlspecialchars($row['intro']);
                $start_date = htmlspecialchars($row['start_date']);
                $last_date = htmlspecialchars($row['last_date']);
                $time_limit = htmlspecialchars($row['time_limit']);

                echo "<tr>
                        <td>{$title}</td>
                        <td>{$start_date}</td>
                        <td>{$last_date}</td>
                        <td>{$intro}</td>
                        <td>{$time_limit}</td>
                      </tr>";
            }
        } else {
            echo "<tr>
                    <td colspan='7' style='text-align:center;'>No upcoming exams found.</td>
                  </tr>";
        }
        ?>
        </tbody>
    </table>
</section>



<section class="contact">
    <h2 id="contact">Contact Us</h2>

    <form id="contactForm" action="server/feedback.php" method="post">

        <div class="form-group">
            <label for="name">Your Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required>
        </div>

        <div class="form-group">
            <label for="email">Your Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required>
        </div>

        <div class="form-group">
            <label for="subject">Subject</label>
            <input type="text" id="subject" name="subject" placeholder="Enter your subject" required>
        </div>

        <div class="form-group">
            <label for="message">Your Message</label>
            <textarea id="message" name="message" placeholder="Type your message here..." required></textarea>
        </div>

        <button type="submit" class="btn-join">Send Message</button>

    </form>
</section>


<style>
    /* Contact Form Styles */
    .contact {
        margin-bottom: 50px;
    }

    .contact h2 {
        color: #ff6600;
        margin-bottom: 20px;
        border-bottom: 2px solid #ff6600;
        display: inline-block;
        padding-bottom: 5px;
    }

    form {
        background-color: #f9f9f9;
        padding: 25px;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    }

    .form-group {
        display: flex;
        flex-direction: column;
        margin-bottom: 15px;
    }

    label {
        margin-bottom: 5px;
        font-weight: bold;
    }

    input, textarea {
        padding: 10px 12px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 16px;
    }

    input:focus, textarea:focus {
        border-color: #ff6600;
        outline: none;
    }

    textarea {
        resize: vertical;
        min-height: 120px;
    }

    .btn-join {
        width: 150px;
        text-align: center;
        background-color: #ff6600;
        color: white;
        border: none;
        padding: 10px 0;
        font-size: 16px;
        border-radius: 5px;
        cursor: pointer;
        transition: 0.3s;
    }

    .btn-join:hover {
        background-color: #e65c00;
    }
</style>


    </main>

    <!-- Footer -->
    <footer>
        &copy; 2025 Online Examination System. All Rights Reserved.
    </footer>

    <!-- JavaScript -->
    <script>
        function joinExam(subject) {
            alert('You are joining the ' + subject + ' exam!');
        }
    </script>
</body>
</html>
